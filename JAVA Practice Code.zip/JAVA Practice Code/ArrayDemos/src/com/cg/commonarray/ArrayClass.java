package com.cg.commonarray;

public class ArrayClass {

	public static void main(String[] args) {

		int[][] arr = new int[1][4];
		System.out.println(arr.getClass().getName());
	}

}
