package com.cg.commonarray;

public class PrimitiveTypeCheck {

	public static void main(String[] args) {

		int a = 1;
		System.out.println(a/2);
	}

}
