package com.cg.commonarray;

public class TestApp {
	
	public static void main(String args[]) {
		Test test ;
		test = new Test(10);
		
		for(int i=0;i<1;i++) {
			System.out.println(test);
		}
	}

}
