package com.cg.demo;

public class HelloWorld {

	public static void main(String[] args) {

		int i,num=10,sum=0;
		for(i=0;i<=num;i++) {
			sum+=i;
		}
		System.out.println(sum);
	}
}