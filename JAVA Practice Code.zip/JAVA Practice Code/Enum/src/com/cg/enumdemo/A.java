package com.cg.enumdemo;

public class A {

	A a = new A();
	
	public static void main(String[] args) {

		A b = new A();

	}
}