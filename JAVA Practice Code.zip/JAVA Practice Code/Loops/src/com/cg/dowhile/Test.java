package com.cg.dowhile;

public class Test {

	public static void main(String[] args) {

		int i=1;
		do {
			System.out.println("Entered with i= "+i);
			i++;
		}while(i<2);
	}
}