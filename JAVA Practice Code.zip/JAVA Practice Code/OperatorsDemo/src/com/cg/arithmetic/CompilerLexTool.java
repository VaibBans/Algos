package com.cg.arithmetic;

public class CompilerLexTool {

	public static void main(String[] args) {

		int a=0,b=1,c=4;
		a += ++b+c;
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
	}

}
