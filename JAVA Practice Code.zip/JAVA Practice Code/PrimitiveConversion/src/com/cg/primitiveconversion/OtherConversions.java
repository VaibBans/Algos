package com.cg.primitiveconversion;

public class OtherConversions {

	public static void main(String[] args) {
		int i = 50;
		byte b = (byte)i;
		System.out.println(i);
		System.out.println(b);
		byte c = (byte) (b*2);

	}

}
