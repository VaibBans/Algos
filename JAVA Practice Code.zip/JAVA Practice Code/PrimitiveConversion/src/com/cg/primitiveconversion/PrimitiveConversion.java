package com.cg.primitiveconversion;

public class PrimitiveConversion {

	public static void main(String[] args) {

		double a = 1;
		double b = 2;
		int aa = 11;
		a = aa;
		System.out.println(a);
		System.out.println(1+2);
		System.out.println("A"+a+b);
		System.out.println(1+2+"A"+1);
		System.out.println((char)('A'+1));
		System.out.println('A'+'B');
		System.out.println('A');
		System.out.println('B');
		System.out.println('A'+'B'+"A"+"B");
		System.out.println("A"+"B"+'A'+'B'+1);
	}

}
