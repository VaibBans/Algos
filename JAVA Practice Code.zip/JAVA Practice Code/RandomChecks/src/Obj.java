

public class Obj {
	Obj obj = new Obj();
	
	
	
	public Obj() {
	}



	public static void main(String[] args) {
		Obj obj1 = new Obj();

	}
} 