package com.cg.scope;

public class A {
	public int a=1;
	protected int b=2;
	int c = 3;
	static private int d = 4;

}
