package com.cg.variablescope;

public class ComparingString {

	public static void main(String[] args) {

		String str1 = new String("a");
		String str2 = new String("a");
		
		System.out.println(str1==str2);
	}

}
