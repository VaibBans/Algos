package com.cg.var;

public class Base {
	static int x = 10;
}

class Derived extends Base{
	
	
	public Derived() {
		super();
		// TODO Auto-generated constructor stub
	}

	static void fun() {
		System.out.println();
	}
}
