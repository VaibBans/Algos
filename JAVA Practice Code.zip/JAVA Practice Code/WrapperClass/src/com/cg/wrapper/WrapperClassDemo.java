package com.cg.wrapper;

public class WrapperClassDemo {

	public static void main(String[] args) {
		Integer a = new Integer(12345);
		int b = 10;

		System.out.println(a+ " "+b);
	}

}
